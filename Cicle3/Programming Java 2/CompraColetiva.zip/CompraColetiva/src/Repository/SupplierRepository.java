package Repository;

import Domain.Supplier;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: Rafael
 * Date: 09/11/13
 * Time: 15:54
 * To change this template use File | Settings | File Templates.
 */
public class SupplierRepository
{
    public void InsertSupplier(Supplier supplier)
    {
        FileOutputStream fos = null;
        ObjectOutputStream oos = null;

        try
        {
            fos = new FileOutputStream("Suppliers.dat", true);
            oos = new ObjectOutputStream(fos);

            oos.writeObject(supplier);
            System.out.println("Write supplier");
        }
        catch(IOException ex)
        {
            ex.getStackTrace();
        }
        finally {
            try
            {
                if (oos != null)
                    oos.close();
                if (fos != null)
                    fos .close();
            }
            catch(IOException ex)
            {
                ex.getStackTrace();
            }
        }
    }

    public List<Supplier> GetSuppliers()
    {
        FileInputStream fis = null;
        ObjectInputStream  ois = null;
        List<Supplier> suppliers = new ArrayList<Supplier>();

        try
        {
            fis = new FileInputStream("Suppliers.dat");
            ois = new ObjectInputStream(fis);
            int num = 0;

            while(true)
            {
                try
                {
                    suppliers.add((Supplier) ois.readObject());
                    System.out.println(num++);
                }
                catch(EOFException ex)
                {
                    break;
                }

                System.out.println("End 1");
            }

            System.out.println("End 2");
        }
        catch(IOException ex)
        {
            ex.getStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally
        {
            try {
                if (ois != null)
                    ois.close();
                if (fis != null)
                    fis.close();
            }
            catch (IOException ex)
            {
                ex.getStackTrace();
            }
        }

        return suppliers;
    }
}
