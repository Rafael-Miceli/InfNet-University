package Presentation;

/**
 * Created with IntelliJ IDEA.
 * User: Rafael
 * Date: 09/11/13
 * Time: 15:33
 * To change this template use File | Settings | File Templates.
 */
public class CreatePromotion
{
}
