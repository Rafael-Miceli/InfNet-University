package Domain;

import java.io.Serializable;

/**
 * Created with IntelliJ IDEA.
 * User: Rafael
 * Date: 09/11/13
 * Time: 15:47
 * To change this template use File | Settings | File Templates.
 */
public class Supplier implements Serializable
{
    public String _razaoSocial;
    public String _cnpj;
}
